import React from "react";
import StudentDetails from "../components/Students";

const StudentDetail = () =>{
    return (
        <div>
            <StudentDetails />
        </div>
    );
};

export default StudentDetail;