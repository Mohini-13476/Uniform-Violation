import React from "react";
import ImageUploader from "../components/File";
const Upload = () =>{
    return (
        <div>
            <ImageUploader/>
        </div>
    );
};

export default Upload;